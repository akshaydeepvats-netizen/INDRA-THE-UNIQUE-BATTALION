"""INDRA — India's real-time severe-weather intelligence & 0–6 h convective nowcasting platform.

Run locally:  python app.py          (http://127.0.0.1:5000)
Production:   gunicorn -c gunicorn.conf.py app:app
"""
import csv
import io
import re
import json
import logging
import math
import os
import time

import numpy as np
from flask import Flask, Response, jsonify, request, send_from_directory, stream_with_context
from flask.json.provider import DefaultJSONProvider

from indra import config, geo, hazards as HZ, imd, lightning, models, net, store, tracking
from indra.engine import ENGINE

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("indra")


class NumpyJSON(DefaultJSONProvider):
    sort_keys = False

    def default(self, o):
        if isinstance(o, np.generic):
            return o.item()
        if isinstance(o, np.ndarray):
            return o.tolist()
        if isinstance(o, set):
            return sorted(o)
        return super().default(o)


app = Flask(__name__, static_folder="static", static_url_path="/static")
app.json = NumpyJSON(app)


@app.after_request
def cors(resp):
    resp.headers["Access-Control-Allow-Origin"] = config.CORS_ORIGINS
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
    resp.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    if request.path.startswith("/api/") and "Cache-Control" not in resp.headers:
        resp.headers["Cache-Control"] = "no-store"
    return resp


_started = False


def ensure_engine():
    global _started
    if not _started and config.ENGINE_ENABLED:
        _started = True
        ENGINE.start()


@app.before_request
def _boot():
    ensure_engine()


def fnum(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None


def age(ts):
    return None if not ts else round(time.time() - ts)


# ------------------------------------------------------------------ pages
@app.get("/")
def index():
    return send_from_directory("static", "index.html")


@app.get("/api")
@app.get("/api/docs")
def docs():
    return jsonify({"name": "INDRA public API", "version": config.VERSION, "endpoints": {
        "GET /api/status": "Feed health, freshness and engine loops",
        "GET /api/stream": "Server-sent events: live log, lightning, alerts, fusion cycles",
        "GET /api/national": "National threat summary and priority districts",
        "GET /api/states": "Threat for all 36 states/UTs",
        "GET /api/states/<slug>/districts": "District threat for one state",
        "GET /api/district/<id>": "District report: threat timeline, cities/towns, cells, alerts",
        "GET /api/place/<id>/villages": "Villages grouped under a city/town",
        "GET /api/search?q=": "State / district / city / town / village search (offline gazetteer)",
        "GET /api/location?lat=&lon=": "Full hazard report for any point: multi-model, nowcast 0–6 h, nearby cells, ETA",
        "GET /api/models?lat=&lon=": "Independent model comparison (ECMWF, GFS, ICON, UKMO, AIFS)",
        "GET /api/cells": "Detected storm cells with motion, corridor, ETA, impact",
        "GET /api/radar": "Radar frames and processing status",
        "GET /api/satellite": "Satellite frames and processing status",
        "GET /api/lightning?minutes=": "Lightning strikes, density and trend",
        "GET /api/alerts?status=": "Alerts (ACTIVE / ENDING / EXPIRED / all)",
        "POST /api/alerts/<id>/ack": "Acknowledge alert",
        "GET /api/verification": "Forecast verification scores (POD, FAR, CSI)",
        "GET /api/history": "National threat history and observed cell replay",
        "GET /api/overlay/hazard.png?hazard=&lead=": "Hazard overlay (Web-Mercator image, bounds in /api/status)",
        "GET /api/overlay/sat.png?layer=&time=": "EUMETSAT Meteosat IODC layer, Web-Mercator, proxied + cached",
        "GET /api/overlay/radar.png": "QC'd radar reflectivity analysis overlay",
        "GET /api/imd": "Official IMD feed status/records",
    }})


# ------------------------------------------------------------------ status
@app.get("/api/health")
def health():
    return jsonify({"system": "INDRA", "status": "OK", "version": config.VERSION, "time": time.time(),
                    "engine_started": _started, "uptime_s": round(time.time() - ENGINE.started)})


def feed_state(name, live_age_limit):
    f = net.FEEDS.get(name)
    if not f:
        return "CONNECTING"
    if f["last_ok"] and time.time() - f["last_ok"] < live_age_limit:
        return "LIVE"
    if f["last_ok"]:
        return "STALE"
    return "UNAVAILABLE"


@app.get("/api/status")
def status():
    r, s, g = ENGINE.radar, ENGINE.sat, ENGINE.grid
    ls = lightning.STATE
    feeds = [
        {"id": "radar", "name": "Radar composite", "provider": "RainViewer (public aggregator)", "state": r.get("status"),
         "data_time": r.get("frame_time"), "age_s": age(r.get("frame_time")), "detail": f"{r.get('cells', 0)} cells · {r.get('tiles_ok', 0)}/{r.get('tiles_total', 0)} tiles",
         "authoritative": False, "note": "Partial coverage over India. Not the IMD DWR network."},
        {"id": "satellite", "name": "Geostationary IR satellite", "provider": "EUMETSAT Meteosat IODC (45.5°E) SEVIRI 10.8 µm", "state": s.get("status"),
         "data_time": s.get("frame_time"), "age_s": age(s.get("frame_time")), "detail": f"{s.get('objects', 0)} cold-cloud objects · {s.get('convective_initiation', 0)} CI",
         "authoritative": False, "note": "Brightness temperature estimated from rendered imagery."},
        {"id": "lightning", "name": "Lightning detection", "provider": "Blitzortung.org community network", "state": "LIVE" if ls["connected"] else ("CONNECTING" if not ls["error"] else "UNAVAILABLE"),
         "data_time": ls.get("last_strike"), "age_s": age(ls.get("last_message")), "detail": f"{len(lightning.recent(15))} India strikes / 15 min",
         "authoritative": False, "note": "Volunteer network; detection efficiency over India varies. Not IMD/IITM."},
        {"id": "models", "name": "NWP model grid", "provider": "Open-Meteo (ECMWF/GFS/ICON best-match)", "state": g.get("status"),
         "data_time": g.get("fetched_at"), "age_s": age(g.get("fetched_at")), "detail": f"{g.get('valid', 0)} pts @ {config.MODEL_GRID_DEG}° · 0–6 h",
         "authoritative": False},
        {"id": "imd", "name": "IMD official warnings / nowcast", "provider": "India Meteorological Department", "state": feed_state("imd_official", 900) if net.FEEDS.get("imd_official") else "NOT CHECKED",
         "authoritative": True, "note": "Requires IMD IP whitelisting or token."},
        {"id": "dwr", "name": "IMD Doppler Weather Radar (reflectivity/velocity)", "provider": "IMD", "state": "NOT CONNECTED", "authoritative": True,
         "note": "No public machine-readable feed. Requires IMD data agreement."},
        {"id": "insat", "name": "INSAT-3D/3DR/3DS imagery", "provider": "ISRO / MOSDAC / IMD", "state": "NOT CONNECTED", "authoritative": True,
         "note": "MOSDAC requires registered access; adapter slot available."},
        {"id": "ilds", "name": "IMD / IITM lightning network", "provider": "IITM (Damini)", "state": "NOT CONNECTED", "authoritative": True,
         "note": "No public API."},
    ]
    return jsonify({"version": config.VERSION, "time": time.time(), "uptime_s": round(time.time() - ENGINE.started),
                    "national_level": ENGINE.national.get("level"), "fusion_id": ENGINE.fusion_id, "fusion_at": ENGINE.fusion_at,
                    "feeds": feeds, "loops": ENGINE.loops, "http": net.FEEDS,
                    "grid": {"bounds": [[5.0, 66.0], [38.0, 99.0]], "res_deg": 0.025, "model_grid_deg": config.MODEL_GRID_DEG},
                    "radar": {k: v for k, v in r.items() if k != "frames"}, "satellite": s,
                    "model_runs": g.get("runs"), "lightning": ls})


@app.get("/api/stream")
def stream():
    last = int(request.args.get("since") or request.headers.get("Last-Event-ID") or 0)

    @stream_with_context
    def gen():
        nonlocal last
        yield "retry: 4000\n\n"
        if last == 0:
            for e in list(ENGINE.events)[-40:]:
                last = e["id"]
                yield f"id: {e['id']}\ndata: {json.dumps(e, default=float)}\n\n"
        t_end = time.time() + 600
        while time.time() < t_end:
            with ENGINE.cond:
                ENGINE.cond.wait(timeout=15)
            evs = ENGINE.events_since(last)
            if not evs:
                yield ": heartbeat\n\n"
                continue
            for e in evs:
                last = e["id"]
                yield f"id: {e['id']}\ndata: {json.dumps(e, default=float)}\n\n"
    return Response(gen(), mimetype="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.get("/api/events")
def events_poll():
    since = int(request.args.get("since", 0))
    return jsonify({"events": ENGINE.events_since(since)[-200:], "last_id": ENGINE.ev_id})


# ------------------------------------------------------------------ atlas
@app.get("/api/national")
def national():
    return jsonify({**ENGINE.national, "states": list(ENGINE.states.values())})


@app.get("/api/states")
def states():
    return jsonify({"generated_at": ENGINE.fusion_at, "states": list(ENGINE.states.values())})


@app.get("/api/states/<slug>/districts")
def state_districts(slug):
    st = geo.STATE_BY_SLUG.get(slug)
    if not st:
        return jsonify({"error": "unknown state"}), 404
    ds = [ENGINE.districts.get(i) or {"id": i, "name": geo.DISTRICT_BY_ID[i]["name"], "level": "UNKNOWN", "score": None}
          for i in st["district_ids"]]
    return jsonify({"state": st["name"], "slug": slug, "generated_at": ENGINE.fusion_at, "state_threat": ENGINE.states.get(slug),
                    "districts": sorted(ds, key=lambda x: -(x.get("score") or -1))})


def _cell_brief(c):
    return {k: c[k] for k in ("id", "source", "lat", "lon", "severity", "primary_hazard", "area_km2", "motion", "trend", "intensity", "lightning_15min")}


@app.get("/api/district/<int:did>")
def district(did):
    d = geo.DISTRICT_BY_ID.get(did)
    if not d:
        return jsonify({"error": "unknown district"}), 404
    threat = ENGINE.districts.get(did)
    towns = geo.towns_in_district(did)
    cells = [c for c in ENGINE.cells if any(x["id"] == did for x in c["impact"]["now"]["districts"] + c["impact"]["forecast"]["districts"])]
    with store.db() as con:
        alerts = [dict(r) for r in con.execute("SELECT id,title,level,peak_level,status,hazard,created_at,updated_at FROM alerts WHERE district_id=? ORDER BY updated_at DESC LIMIT 20", (did,))]
    return jsonify({"district": d, "threat": threat, "towns": towns, "village_count": geo.village_count(did),
                    "cells": [{**_cell_brief(c), "eta": next((x for x in c["impact"]["forecast"]["districts"] if x["id"] == did), None)} for c in cells],
                    "alerts": alerts, "precautions": HZ.precautions((threat or {}).get("hazards", {})),
                    "hierarchy_note": "Cities/towns and villages from GeoNames (CC-BY 4.0). Villages are grouped under their nearest town within the district."})


@app.get("/api/place/<int:pid>/villages")
def villages(pid):
    p = geo.place(pid)
    if not p:
        return jsonify({"error": "unknown place"}), 404
    return jsonify({"place": p, "villages": geo.villages_of_town(pid)})


@app.get("/api/search")
def search():
    q = request.args.get("q", "")
    res = geo.search(q, limit=14)
    source = "INDRA gazetteer (offline)"
    if not res and len(q.strip()) >= 3:
        data, meta = net.get(config.GEOCODER_URL, params={"q": q + ", India", "format": "jsonv2", "limit": 6, "countrycodes": "in"},
                             ttl=86400, feed="nominatim")
        for item in data or []:
            la, lo = fnum(item.get("lat")), fnum(item.get("lon"))
            if la is None:
                continue
            dd = geo.district_at(la, lo)
            res.append({"type": "place", "name": item.get("name") or item.get("display_name", "").split(",")[0], "lat": la, "lon": lo,
                        "district": dd and dd["name"], "state": dd and dd["state"], "district_id": dd and dd["id"],
                        "label": item.get("display_name", "")[:120]})
        source = "OpenStreetMap Nominatim (fallback)"
    return jsonify({"query": q, "source": source, "results": res})


# ------------------------------------------------------------------ location report
def _point_hazard_models(multi):
    """Hazard diagnostics per model per lead hour; mean and spread (model agreement)."""
    leads = min(7, len(multi.get("times") or []))
    per = {}
    for m in multi.get("models", []):
        if m["status"] == "NO_DATA":
            continue
        h = m["hourly"]
        per[m["id"]] = [models.hazard_scores(h, i) for i in range(leads)]
    out = []
    for i in range(leads):
        row = {"lead_h": i, "valid_time": multi["times"][i]}
        for k in HZ.HAZARDS:
            vals = [per[mid][i][k] for mid in per]
            if vals:
                row[k] = {"mean": round(float(np.mean(vals))), "max": max(vals), "min": min(vals), "spread": max(vals) - min(vals)}
        out.append(row)
    return out, list(per)


@app.get("/api/location")
def location():
    lat, lon = fnum(request.args.get("lat")), fnum(request.args.get("lon"))
    if lat is None or lon is None or not (-90 <= lat <= 90 and -180 <= lon <= 180):
        return jsonify({"error": "valid lat/lon required"}), 400
    name = (request.args.get("name") or "").strip()[:120]
    d = geo.district_at(lat, lon)
    multi = models.point_multi(lat, lon, hours=13)
    haz_models, used = _point_hazard_models(multi) if multi.get("models") else ([], [])
    dthreat = ENGINE.districts.get(d["id"]) if d else None
    # nearby cells and ETA to this exact point
    near = []
    for c in ENGINE.cells:
        dist = tracking.km_between(lat, lon, c["lat"], c["lon"])
        if dist > 250:
            continue
        eta = None
        for p in c["forecast_path"]:
            if tracking.km_between(lat, lon, p["lat"], p["lon"]) <= p["radius_km"]:
                eta = p["lead_min"]
                break
        near.append({**_cell_brief(c), "distance_km": round(dist, 1), "eta_min": eta})
    near.sort(key=lambda x: (x["eta_min"] if x["eta_min"] is not None else 999, x["distance_km"]))
    strikes15 = lightning.count_near(lat, lon, 25, 15)
    strikes60 = lightning.count_near(lat, lon, 25, 60)
    # fused 0-6 h nowcast at this point
    timeline = []
    for i in range(7):
        row = {"lead_h": i}
        for k in HZ.HAZARDS:
            mv = haz_models[i][k]["mean"] if i < len(haz_models) and k in haz_models[i] else 0
            mv = min(mv, HZ.MODEL_ONLY_CAP)
            ov = 0
            for c in near:
                if c["eta_min"] is not None and c["eta_min"] // 60 <= i <= c["eta_min"] // 60 + (1 if c["eta_min"] < 60 else 0):
                    full = next((x for x in ENGINE.cells if x["id"] == c["id"]), None)
                    if full:
                        ov = max(ov, full["hazards"][k] * (1 - 0.12 * i))
            if k == "lightning" and i == 0 and strikes15:
                ov = max(ov, 50 if strikes15 < 5 else 70 if strikes15 < 15 else 88)
            row[k] = round(max(mv, ov))
            row[k + "_src"] = "observed+extrapolated" if ov > mv else "model"
        row["score"] = max(row[k] for k in HZ.HAZARDS)
        row["level"] = HZ.level(row["score"])
        timeline.append(row)
    sources = ["model"] + (["radar"] if any(c["source"] == "radar" for c in near if c["eta_min"] is not None) else []) + \
              (["satellite"] if any(c["source"] == "satellite" for c in near if c["eta_min"] is not None) else []) + (["lightning"] if strikes15 else [])
    peak = max(timeline, key=lambda r: r["score"]) if timeline else None
    spread = None
    if haz_models:
        spread = max(haz_models[0].get(k, {}).get("spread", 0) for k in HZ.HAZARDS) / 100
    cur = {}
    for m in multi.get("models", []):
        if m["status"] != "NO_DATA":
            cur[m["id"]] = {v: (m["hourly"].get(v) or [None])[0] for v in models.POINT_HOURLY}
    return jsonify({
        "location": {"name": name or (d["name"] if d else "Selected point"), "lat": lat, "lon": lon,
                     "district": d and {"id": d["id"], "name": d["name"], "state": d["state"]}},
        "generated_at": time.time(),
        "threat": {"level": peak["level"] if peak else "UNKNOWN", "score": peak["score"] if peak else None,
                   "peak_lead_h": peak["lead_h"] if peak else None,
                   "primary_hazard": max(HZ.HAZARDS, key=lambda k: peak[k]) if peak else None},
        "nowcast": timeline, "model_hazards": haz_models, "models_used": used,
        "current": cur, "models": multi, "ensemble": models.ensemble_stats(multi) if multi.get("models") else [],
        "district_threat": dthreat, "nearby_cells": near[:10], "lightning": {"within_25km_15min": strikes15, "within_25km_60min": strikes60},
        "confidence": HZ.confidence(sources, spread, lead_h=peak["lead_h"] if peak else 0),
        "precautions": HZ.precautions({k: peak[k] for k in HZ.HAZARDS} if peak else {}),
        "labels": {"nowcast": "EXPERIMENTAL", "models": "LIVE model output (Open-Meteo)", "observations": "LIVE where available",
                   "official": "Not an IMD warning"},
        "official_warning": {"status": "SEE IMD", "url": "https://mausam.imd.gov.in/responsive/districtWiseNowcast.php"},
    })


@app.get("/api/nowcast")
def nowcast():
    hz = request.args.get("hazard", "all")
    lead = int(min(6, max(0, fnum(request.args.get("lead")) or 0)))
    F = getattr(ENGINE, "F", None)
    if F is None:
        return jsonify({"status": "INITIALISING", "districts": []})
    if hz in HZ.HAZARDS:
        v = F[:, lead, HZ.HAZARDS.index(hz)]
    else:
        hz, v = "all", F[:, lead, :].max(axis=1)
    order = np.argsort(-v)[:40]
    out = []
    for i in order:
        if v[i] < 20:
            break
        d = geo.DISTRICTS[int(i)]
        x = ENGINE.districts.get(d["id"], {})
        out.append({"id": d["id"], "name": d["name"], "state": d["state"], "lat": d["lat"], "lon": d["lon"], "score": int(round(float(v[i]))),
                    "level": HZ.level(float(v[i])), "sources": x.get("sources", []), "eta": x.get("eta")})
    return jsonify({"status": "OK", "hazard": hz, "lead_h": lead, "generated_at": ENGINE.fusion_at, "label": "EXPERIMENTAL",
                    "counts": {lv: int((v >= th).sum()) for lv, th in (("LOW", 20), ("MEDIUM", 40), ("HIGH", 60), ("CRITICAL", 80))},
                    "national_timeline": ENGINE.national.get("timeline"), "by_hazard": ENGINE.national.get("timeline_by_hazard"),
                    "method": {"0-2 h": "Observed radar/satellite cells advected along tracked motion; lightning nowcast from last 30 min",
                               "2-6 h": "Blend toward NWP convective diagnostics (CAPE, lifted index, CIN, precipitation, gusts, freezing level); model-only signals capped at HIGH",
                               "uncertainty": "Grows with lead time and model spread; see confidence fields"},
                    "districts": out})


@app.get("/api/models")
def models_cmp():
    lat, lon = fnum(request.args.get("lat")), fnum(request.args.get("lon"))
    if lat is None or lon is None:
        return jsonify({"error": "valid lat/lon required"}), 400
    multi = models.point_multi(lat, lon, hours=int(min(48, fnum(request.args.get("hours")) or 13)))
    return jsonify({"lat": lat, "lon": lon, "runs": ENGINE.grid.get("runs") or models.model_runs(), "data": multi,
                    "ensemble": models.ensemble_stats(multi) if multi.get("models") else []})


# ------------------------------------------------------------------ observations
@app.get("/api/cells")
def cells():
    src = request.args.get("source")
    cs = ENGINE.cells
    if src:
        cs = [c for c in cs if c["source"] == src]
    return jsonify({"generated_at": ENGINE.fusion_at, "radar_frame": ENGINE.radar_frame_t, "satellite_frame": ENGINE.sat_frame_t,
                    "count": len(cs), "cells": cs,
                    "method": "Radar cells: connected regions ≥35 dBZ after QC on 0.025° grid. Satellite cells: IR10.8 ≤235 K (estimated) "
                              "objects with convective signals, not overlapping radar cells. Tracking: overlap-weighted nearest neighbour across frames. "
                              "Forecast: linear extrapolation with growing uncertainty (EXPERIMENTAL)."})


@app.get("/api/cells/<cid>")
def cell(cid):
    c = next((x for x in ENGINE.cells if x["id"] == cid), None)
    if not c:
        return jsonify({"error": "cell not active"}), 404
    return jsonify(c)


@app.get("/api/radar")
def radar_info():
    r = ENGINE.radar
    host = r.get("host", "https://tilecache.rainviewer.com")
    frames = [{"time": f["time"], "tiles": f"{host}{f['path']}/256/{{z}}/{{x}}/{{y}}/2/1_0.png"} for f in r.get("frames", [])]
    return jsonify({"status": r.get("status"), "frame_time": r.get("frame_time"), "frames": frames, "cells": r.get("cells"),
                    "provider": "RainViewer", "max_zoom": 7, "attribution": "Radar © RainViewer",
                    "notice": "Public radar composite; partial coverage over India; not IMD DWR."})


@app.get("/api/satellite")
def sat_info():
    s = ENGINE.sat
    return jsonify({**s, "wms": config.EUMETSAT_WMS, "layers": {
        "ir108": "msg_iodc:ir108", "convection": "msg_iodc:rgb_convection", "airmass": "msg_iodc:rgb_airmass",
        "cloud_top_height": "msg_iodc:cth", "water_vapour": "msg_iodc:wv062", "visible": "msg_iodc:vis006",
        "lifted_index": "msg_iodc:gii_liftedindex", "precip_rate": "msg_iodc:h63"},
        "attribution": "Satellite © EUMETSAT (Meteosat IODC)",
        "insat": {"status": "NOT CONNECTED", "note": "INSAT-3DR/3DS via MOSDAC requires registration."}})


@app.get("/api/lightning")
def lightning_api():
    minutes = int(min(180, fnum(request.args.get("minutes")) or 30))
    rows = lightning.recent(minutes)
    dens = lightning.density(minutes)
    for c in dens["cells"][:25]:
        d = geo.district_at(c["lat"], c["lon"])
        c["district"], c["state"] = (d["name"], d["state"]) if d else (None, None)
    return jsonify({"state": lightning.STATE, "minutes": minutes, "count": len(rows),
                    "strikes": [[round(t, 1), la, lo] for t, la, lo in rows[-5000:]],
                    "density": dens, "trend": lightning.trend(120, 5),
                    "attribution": "Lightning data © Blitzortung.org contributors (community network, non-authoritative)"})


# ------------------------------------------------------------------ alerts
@app.get("/api/alerts")
def alerts():
    st = request.args.get("status", "active").lower()
    q = "SELECT * FROM alerts"
    args = ()
    if st == "active":
        q += " WHERE status IN ('ACTIVE','ENDING')"
    elif st != "all":
        q += " WHERE status=?"
        args = (st.upper(),)
    q += " ORDER BY updated_at DESC LIMIT 400"
    rank = {lv: i for i, lv in enumerate(HZ.LEVELS)}
    with store.db() as con:
        rows = [dict(r) for r in con.execute(q, args)]
    for r in rows:
        r["payload"] = json.loads(r["payload"] or "{}")
        r["source_label"] = "INDRA EXPERIMENTAL SCREENING ALERT — not an official IMD warning"
    rows.sort(key=lambda r: (r["status"] != "ACTIVE", -rank.get(r["level"], 0), -r["updated_at"]))
    counts = {lv: sum(1 for r in rows if r["level"] == lv and r["status"] == "ACTIVE") for lv in HZ.LEVELS}
    return jsonify({"generated_at": time.time(), "count": len(rows), "counts": counts, "alerts": rows,
                    "official": {"status": "SEPARATE", "endpoint": "/api/imd"}})


@app.get("/api/alerts/<aid>/history")
def alert_history(aid):
    with store.db() as con:
        evs = [dict(r) for r in con.execute("SELECT * FROM alert_events WHERE alert_id=? ORDER BY at", (aid,))]
    return jsonify({"alert_id": aid, "events": evs})


@app.get("/api/alerts/log")
def alert_log():
    with store.db() as con:
        evs = [dict(r) for r in con.execute("SELECT e.*, a.title, a.hazard FROM alert_events e LEFT JOIN alerts a ON a.id=e.alert_id ORDER BY e.at DESC LIMIT 300")]
    return jsonify({"events": evs})


@app.post("/api/alerts/<aid>/ack")
def ack(aid):
    body = request.get_json(silent=True) or {}
    op = str(body.get("operator", "operator"))[:60] or "operator"
    with store.db() as con:
        n = con.execute("UPDATE alerts SET acknowledged_at=?, acknowledged_by=? WHERE id=?", (time.time(), op, aid)).rowcount
        con.execute("INSERT INTO alert_events(alert_id,at,event,level,note) VALUES(?,?,?,?,?)", (aid, time.time(), "ACKNOWLEDGED", None, op))
    store.audit(op, "ACK_ALERT", aid)
    ENGINE.emit("ack", {"id": aid, "operator": op})
    return jsonify({"ok": bool(n), "alert_id": aid})


@app.get("/api/imd")
def imd_api():
    return jsonify(imd.summary())


# ------------------------------------------------------------------ verification / history
@app.get("/api/verification")
def verification():
    hours = int(min(72, fnum(request.args.get("hours")) or 24))
    cutoff = time.time() - hours * 3600
    with store.db() as con:
        rows = con.execute("SELECT method, lead_min, SUM(hits) h, SUM(misses) m, SUM(false_alarms) f, SUM(correct_negatives) c, COUNT(*) n "
                           "FROM verification WHERE valid_at>=? GROUP BY method, lead_min", (cutoff,)).fetchall()
        series = [dict(r) for r in con.execute("SELECT valid_at, lead_min, method, hits, misses, false_alarms FROM verification WHERE valid_at>=? ORDER BY valid_at", (cutoff,))]
        pending = con.execute("SELECT COUNT(*) FROM forecasts WHERE verified=0").fetchone()[0]
        labels = con.execute("SELECT COUNT(*) FROM feedback").fetchone()[0]
    out = []
    for r in rows:
        h, m, f = r["h"] or 0, r["m"] or 0, r["f"] or 0
        out.append({"method": r["method"], "lead_min": r["lead_min"], "samples": r["n"], "hits": h, "misses": m, "false_alarms": f,
                    "pod": round(h / (h + m), 3) if h + m else None, "far": round(f / (h + f), 3) if h + f else None,
                    "csi": round(h / (h + m + f), 3) if h + m + f else None,
                    "bias": round((h + f) / (h + m), 3) if h + m else None})
    best = max((x for x in out if x["method"] == "extrapolation" and x["csi"] is not None), key=lambda x: x["samples"], default=None)
    return jsonify({"window_hours": hours, "scores": sorted(out, key=lambda x: (x["method"], x["lead_min"])), "series": series[-600:],
                    "pending_forecasts": pending, "event_labels": labels,
                    "target": {"metric": "POD ≥ 0.80 with CSI reported", "status": ("MET on this window" if best and best["pod"] and best["pod"] >= 0.8 else "NOT DEMONSTRATED"),
                               "note": "Automatic radar self-verification measures extrapolation skill against later RainViewer observations "
                                       "(10 km tolerance). It is not independent ground truth. An 80% accuracy claim needs a verified historical event archive."},
                    "methods": {"extrapolation": "INDRA cell advection forecast vs observed ≥35 dBZ (0.1° boxes)",
                                "persistence": "No-motion baseline", "model_thunder_vs_lightning": "Model thunderstorm screening (≥40) vs community lightning within 40 km ±30 min"}})


@app.get("/api/history")
def history():
    hours = int(min(72, fnum(request.args.get("hours")) or 24))
    cutoff = time.time() - hours * 3600
    with store.db() as con:
        th = [{"at": r["at"], **json.loads(r["payload"])} for r in con.execute("SELECT at,payload FROM threat_history WHERE at>=? ORDER BY at", (cutoff,))]
        ch = [{"at": r["at"], "source": r["source"], "cells": json.loads(r["payload"])} for r in
              con.execute("SELECT at,source,payload FROM cell_history WHERE at>=? ORDER BY at", (cutoff,))]
    return jsonify({"threat": th, "cells": ch, "label": "OBSERVED HISTORY (archived by this INDRA instance)"})


@app.get("/api/replay/demo")
def replay_demo():
    o_lat, o_lon = 20.30, 85.82
    track = [{"lead_min": k * 20, "lat": round(o_lat + k * 0.09, 3), "lon": round(o_lon + k * 0.05, 3),
              "max_dbz": min(63, 44 + k * 1.6), "radius_km": round(12 + k * 1.5, 1)} for k in range(19)]
    return jsonify({"mode": "SIMULATION", "is_live": False, "scenario": "Synthetic convective cell, coastal Odisha", "track": track,
                    "notice": "Fictional scenario for operator training. Not observed data and not a forecast."})


@app.get("/api/audit")
def audit():
    with store.db() as con:
        rows = [dict(r) for r in con.execute("SELECT * FROM audit ORDER BY at DESC LIMIT 200")]
    return jsonify({"events": rows})


@app.post("/api/feedback")
def feedback():
    b = request.get_json(silent=True) or {}
    et = str(b.get("event_type", "")).upper()[:40]
    oc = str(b.get("outcome", "")).upper()[:20]
    if et not in {"THUNDERSTORM", "HAIL", "CLOUDBURST", "HEAVY_RAIN", "LIGHTNING", "DOWNBURST", "FLASH_FLOOD", "OTHER"} or oc not in {"OBSERVED", "NOT_OBSERVED", "UNKNOWN"}:
        return jsonify({"error": "invalid event_type/outcome"}), 400
    with store.db() as con:
        con.execute("INSERT INTO feedback(created_at,location,event_type,outcome,notes) VALUES(?,?,?,?,?)",
                    (time.time(), str(b.get("location", ""))[:160], et, oc, str(b.get("notes", ""))[:1000]))
    store.audit(str(b.get("operator", "operator"))[:60], "EVENT_LABEL", str(b.get("location", ""))[:160], {"event": et, "outcome": oc})
    return jsonify({"ok": True}), 201


@app.get("/api/feedback")
def feedback_list():
    with store.db() as con:
        rows = [dict(r) for r in con.execute("SELECT * FROM feedback ORDER BY id DESC LIMIT 100")]
    return jsonify({"events": rows})


@app.get("/api/export/<name>.csv")
def export(name):
    q = {"alerts": "SELECT id,kind,hazard,level,peak_level,title,district,state,lat,lon,status,created_at,updated_at,acknowledged_at,acknowledged_by FROM alerts ORDER BY created_at DESC",
         "feedback": "SELECT * FROM feedback ORDER BY id DESC", "verification": "SELECT * FROM verification ORDER BY valid_at DESC",
         "audit": "SELECT * FROM audit ORDER BY at DESC"}.get(name)
    if not q:
        return jsonify({"error": "unknown export"}), 404
    with store.db() as con:
        cur = con.execute(q)
        cols = [c[0] for c in cur.description]
        rows = cur.fetchall()
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(cols)
    w.writerows([tuple(r) for r in rows])
    return Response(out.getvalue(), mimetype="text/csv", headers={"Content-Disposition": f"attachment; filename=indra_{name}.csv"})


# ------------------------------------------------------------------ overlays
@app.get("/api/overlay/hazard.png")
def overlay_hazard():
    hz = request.args.get("hazard", "all")
    if hz != "all" and hz not in HZ.HAZARDS:
        hz = "all"
    lead = int(min(6, max(0, fnum(request.args.get("lead")) or 0)))
    png = ENGINE.overlay_hazard(hz, lead)
    if png is None:
        return Response(status=204)
    return Response(png, mimetype="image/png", headers={"Cache-Control": "max-age=60"})


@app.get("/api/overlay/sat.png")
def overlay_sat():
    from indra import satellite as SAT
    layer = request.args.get("layer", "msg_iodc:ir108")
    t = request.args.get("time", "")
    if t and not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{3})?Z", t):
        return jsonify({"error": "bad time"}), 400
    data, meta = SAT.display_png(layer, t)
    if not data:
        return jsonify({"error": meta.get("error") or "satellite image unavailable", "status": "UNAVAILABLE"}), 502
    return Response(data, mimetype="image/png", headers={"Cache-Control": "public, max-age=3600", "X-INDRA-Feed": meta.get("status", "")})


@app.get("/api/overlay/radar.png")
def overlay_radar():
    png = ENGINE.overlay_radar()
    if png is None:
        return Response(status=204)
    return Response(png, mimetype="image/png", headers={"Cache-Control": "max-age=60"})


@app.errorhandler(404)
def nf(_):
    if request.path.startswith("/api/"):
        return jsonify({"error": "not found"}), 404
    return send_from_directory("static", "index.html")


@app.errorhandler(500)
def ie(e):
    log.exception("server error")
    return jsonify({"error": "internal error"}), 500


if __name__ == "__main__":
    ensure_engine()
    app.run(host=os.getenv("HOST", "0.0.0.0"), port=int(os.getenv("PORT", "5000")), threaded=True, debug=False)
