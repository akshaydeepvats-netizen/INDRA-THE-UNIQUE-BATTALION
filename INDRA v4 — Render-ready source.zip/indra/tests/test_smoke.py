"""Smoke tests that run offline (engine disabled): python -m pytest -q"""
import os
import sys
from pathlib import Path

os.environ["INDRA_ENGINE"] = "0"
os.environ.setdefault("INDRA_RUNTIME_DIR", str(Path(__file__).parent / ".runtime"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest  # noqa: E402

from app import app  # noqa: E402


@pytest.fixture()
def client():
    app.config["TESTING"] = True
    return app.test_client()


def test_index_served(client):
    r = client.get("/")
    assert r.status_code == 200 and b"INDRA" in r.data


def test_spa_fallback(client):
    assert client.get("/desk/anything").status_code == 200
    assert client.get("/api/does-not-exist").status_code == 404


def test_health(client):
    r = client.get("/api/health")
    assert r.status_code == 200 and "version" in r.get_json()


def test_states_cover_all_36(client):
    gj = client.get("/static/geo/states.geojson").get_json()
    assert len(gj["features"]) == 36  # 28 states + 8 UTs
    assert client.get("/api/states").status_code == 200


def test_district_drilldown(client):
    d = client.get("/api/states/uttar-pradesh/districts").get_json()
    rows = d.get("districts", d)
    assert len(rows) >= 70
    assert any(x["name"] == "Meerut" for x in rows)


def test_search_village_level(client):
    d = client.get("/api/search?q=Sardhana").get_json()
    assert d["results"], d


def test_status_never_claims_simulated_live(client):
    feeds = client.get("/api/status").get_json()["feeds"]
    ids = {f["id"]: f["state"] for f in feeds}
    for k in ("insat", "dwr", "ilds"):
        assert ids[k] != "LIVE"


def test_static_assets(client):
    for p in ("/static/js/app.js", "/static/css/indra.css", "/static/geo/states.geojson"):
        assert client.get(p).status_code == 200, p
