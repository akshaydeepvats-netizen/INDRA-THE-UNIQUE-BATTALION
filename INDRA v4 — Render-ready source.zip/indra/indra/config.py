"""Runtime configuration. Every value can be overridden with an environment variable."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
RUNTIME_DIR = Path(os.getenv("INDRA_RUNTIME_DIR", str(DATA_DIR / "runtime")))
RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = Path(os.getenv("INDRA_DB_PATH", str(RUNTIME_DIR / "indra.sqlite3")))

VERSION = "4.0.0"
USER_AGENT = os.getenv("INDRA_USER_AGENT", "INDRA-Nowcast/4.0 (SIH26084 research prototype)")
HTTP_TIMEOUT = float(os.getenv("INDRA_HTTP_TIMEOUT_SECONDS", "20"))

# Engine cadence (seconds)
ENGINE_ENABLED = os.getenv("INDRA_ENGINE", "1") == "1"
RADAR_INTERVAL = int(os.getenv("INDRA_RADAR_INTERVAL", "300"))
SATELLITE_INTERVAL = int(os.getenv("INDRA_SATELLITE_INTERVAL", "300"))
MODEL_GRID_INTERVAL = int(os.getenv("INDRA_MODEL_GRID_INTERVAL", "3600"))
LIGHTNING_ENABLED = os.getenv("INDRA_LIGHTNING", "1") == "1"

# Open-Meteo (free tier works; set an API key for the commercial endpoint and denser grids)
OPEN_METEO_KEY = os.getenv("OPEN_METEO_API_KEY", "").strip()
OPEN_METEO_URL = ("https://customer-api.open-meteo.com/v1/forecast" if OPEN_METEO_KEY
                  else os.getenv("OPEN_METEO_URL", "https://api.open-meteo.com/v1/forecast"))
MODEL_GRID_DEG = float(os.getenv("INDRA_MODEL_GRID_DEG", "1.0"))

# Radar (RainViewer public composite)
RAINVIEWER_API = os.getenv("RAINVIEWER_API", "https://api.rainviewer.com/public/weather-maps.json")
RADAR_ZOOM = int(os.getenv("INDRA_RADAR_ZOOM", "6"))

# Satellite (EUMETSAT Meteosat Indian Ocean Data Coverage)
EUMETSAT_WMS = os.getenv("EUMETSAT_WMS", "https://view.eumetsat.int/geoserver/wms")
SAT_LAYER = os.getenv("INDRA_SAT_LAYER", "msg_iodc:ir108")

# Official IMD feeds (require IP whitelisting / API token from IMD)
IMD_API_BASE = os.getenv("IMD_API_BASE", "https://api.imd.gov.in/api/v1").rstrip("/")
IMD_API_TOKEN = os.getenv("IMD_API_TOKEN", "").strip()
IMD_LEGACY_BASE = os.getenv("IMD_LEGACY_BASE", "https://mausam.imd.gov.in/api").rstrip("/")

GEOCODER_URL = os.getenv("GEOCODER_URL", "https://nominatim.openstreetmap.org/search")
CORS_ORIGINS = os.getenv("INDRA_CORS", "*")
