"""Radar ingestion: RainViewer public composite -> dBZ on the INDRA analysis grid,
quality control, convective-cell detection.

RainViewer is a public aggregator. Over India its coverage is partial and it is NOT
the IMD Doppler Weather Radar network; INDRA labels it accordingly."""
import csv
import io
import logging
import math
import time
from concurrent.futures import ThreadPoolExecutor

import numpy as np
from PIL import Image
from scipy import ndimage

from . import config, net
from .grid_spec import LAT_N, LON_W, RES, NROWS, NCOLS

log = logging.getLogger("indra.radar")
Z = config.RADAR_ZOOM
COLOR_SCHEME = 2  # Universal Blue (the only scheme the public API currently serves)


def _load_palette():
    rows = list(csv.reader(open(config.DATA_DIR / "rainviewer_colors.csv")))
    header = rows[0]
    col = header.index("Universal Blue")
    pal = []
    for r in rows[1:]:
        hexv = r[col].strip().lstrip("#")
        if len(hexv) == 8 and hexv[6:] != "00":
            pal.append((int(r[0]), int(hexv[0:2], 16), int(hexv[2:4], 16), int(hexv[4:6], 16)))
    return pal


PALETTE = _load_palette()
_PAL_RGB = np.array([p[1:] for p in PALETTE], dtype=np.float32)
_PAL_DBZ = np.array([p[0] for p in PALETTE], dtype=np.float32)


def _tile_x(lon):
    return int((lon + 180) / 360 * 2 ** Z)


def _tile_y(lat):
    r = math.radians(lat)
    return int((1 - math.log(math.tan(r) + 1 / math.cos(r)) / math.pi) / 2 * 2 ** Z)


XS = list(range(_tile_x(LON_W), _tile_x(LON_W + NCOLS * RES) + 1))
YS = list(range(_tile_y(LAT_N), _tile_y(LAT_N - NROWS * RES) + 1))

# Pre-computed sampling indices: analysis-grid cell -> mosaic pixel
_lats = LAT_N - (np.arange(NROWS) + 0.5) * RES
_lons = LON_W + (np.arange(NCOLS) + 0.5) * RES
_px = ((_lons + 180) / 360 * 2 ** Z * 256 - XS[0] * 256).astype(np.int32)
_lr = np.radians(_lats)
_py = ((1 - np.log(np.tan(_lr) + 1 / np.cos(_lr)) / math.pi) / 2 * 2 ** Z * 256 - YS[0] * 256).astype(np.int32)


def frames():
    data, meta = net.get(config.RAINVIEWER_API, ttl=60, feed="radar_index")
    if not data:
        return None, meta
    past = (data.get("radar") or {}).get("past") or []
    return {"host": data.get("host", "https://tilecache.rainviewer.com"), "frames": past,
            "nowcast": (data.get("radar") or {}).get("nowcast") or []}, meta


def _tile(host, path, x, y):
    url = f"{host}{path}/256/{Z}/{x}/{y}/{COLOR_SCHEME}/0_0.png"
    data, meta = net.get(url, ttl=24 * 3600, as_json=False, timeout=15)
    return x, y, data


def decode_frame(host, path):
    """Download the India mosaic for one frame and return dBZ on the analysis grid (NaN = no echo)."""
    W, H = len(XS) * 256, len(YS) * 256
    mos = np.zeros((H, W, 4), dtype=np.uint8)
    ok = 0
    with ThreadPoolExecutor(12) as ex:
        for x, y, data in ex.map(lambda xy: _tile(host, path, *xy), [(x, y) for x in XS for y in YS]):
            if data:
                try:
                    im = np.array(Image.open(io.BytesIO(data)).convert("RGBA"))
                    mos[(y - YS[0]) * 256:(y - YS[0] + 1) * 256, (x - XS[0]) * 256:(x - XS[0] + 1) * 256] = im
                    ok += 1
                except Exception:  # noqa: BLE001
                    pass
    total = len(XS) * len(YS)
    if ok < total * 0.6:
        net.feed_mark("radar_tiles", False, error=f"only {ok}/{total} tiles")
        return None, ok, total
    net.feed_mark("radar_tiles", True, detail=f"{ok}/{total} tiles")
    grid = mos[_py[:, None].clip(0, H - 1), _px[None, :].clip(0, W - 1)]  # (NROWS, NCOLS, 4)
    alpha = grid[..., 3]
    dbz = np.full((NROWS, NCOLS), np.nan, dtype=np.float32)
    m = alpha > 0
    if m.any():
        rgb = grid[m][:, :3].astype(np.float32)
        # map unique colours to the nearest palette entry (handles anti-aliasing)
        uniq, inv = np.unique(rgb, axis=0, return_inverse=True)
        d2 = ((uniq[:, None, :] - _PAL_RGB[None, :, :]) ** 2).sum(-1)
        dbz[m] = _PAL_DBZ[d2.argmin(1)][inv.ravel()]
    return dbz, ok, total


def quality_control(dbz):
    """Remove isolated speckle and thin radial clutter spokes typical of the public composite."""
    valid = np.isfinite(dbz) & (dbz >= 20)
    opened = ndimage.binary_opening(valid, structure=np.ones((3, 3)))
    lab, n = ndimage.label(opened)
    if n:
        sizes = ndimage.sum(opened, lab, range(1, n + 1))
        keep = np.zeros(n + 1, bool)
        keep[1:] = sizes >= 6
        opened = keep[lab]
    out = np.where(opened, dbz, np.nan).astype(np.float32)
    return out


def detect_cells(dbz, threshold=35.0, min_cells=6):
    """Connected regions >= threshold dBZ. Returns objects with footprint masks."""
    core = np.isfinite(dbz) & (dbz >= threshold)
    core = ndimage.binary_closing(core, structure=np.ones((2, 2)))
    lab, n = ndimage.label(core)
    objs = []
    if not n:
        return objs, lab
    slices = ndimage.find_objects(lab)
    for i, sl in enumerate(slices, start=1):
        m = lab[sl] == i
        cnt = int(m.sum())
        if cnt < min_cells:
            continue
        sub = dbz[sl]
        vals = sub[m]
        rr, cc = np.nonzero(m)
        w = np.clip(np.nan_to_num(vals - threshold + 1, nan=0), 0, None)
        if w.sum() <= 0:
            w = np.ones_like(w)
        r = sl[0].start + float((rr * w).sum() / w.sum())
        c = sl[1].start + float((cc * w).sum() / w.sum())
        objs.append({"label": i, "slice": (sl[0].start, sl[0].stop, sl[1].start, sl[1].stop), "mask": m,
                     "r": r, "c": c, "lat": LAT_N - (r + 0.5) * RES, "lon": LON_W + (c + 0.5) * RES,
                     "cells": cnt, "max_dbz": float(np.nanmax(vals)), "mean_dbz": float(np.nanmean(vals)),
                     "p90_dbz": float(np.nanpercentile(vals, 90)),
                     "frac_ge50": float((vals >= 50).mean()), "frac_ge55": float((vals >= 55).mean())})
    return objs, lab


def coarse_mask(field_mask, factor=4):
    """Downsample a boolean grid by `factor` (any-true) for verification storage."""
    h, w = field_mask.shape
    h2, w2 = h // factor, w // factor
    return field_mask[:h2 * factor, :w2 * factor].reshape(h2, factor, w2, factor).any(axis=(1, 3))


def render_png(dbz):
    """Transparent PNG of the QC'd reflectivity field on the analysis grid (EPSG:4326 bounds)."""
    rgba = np.zeros(dbz.shape + (4,), dtype=np.uint8)
    m = np.isfinite(dbz)
    if m.any():
        idx = np.searchsorted(_PAL_DBZ, dbz[m]).clip(0, len(_PAL_DBZ) - 1)
        rgba[m, :3] = _PAL_RGB[idx].astype(np.uint8)
        rgba[m, 3] = 230
    buf = io.BytesIO()
    Image.fromarray(rgba, "RGBA").save(buf, "PNG", optimize=True)
    return buf.getvalue()


def ts():
    return time.time()
